def main():
    print('hello')